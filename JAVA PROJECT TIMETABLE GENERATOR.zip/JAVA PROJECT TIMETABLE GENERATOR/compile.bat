@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion
if exist out rmdir /s /q out
mkdir out
if exist sources.txt del sources.txt
for /r src %%f in (*.java) do (
  set "p=%%f"
  set "p=!p:\=/!"
  echo "!p!">> sources.txt
)
javac -encoding UTF-8 -d out -cp "lib\*" @sources.txt
if errorlevel 1 (
  echo.
  echo COMPILE FAILED. Take a screenshot of this window and send it.
  pause
  exit /b 1
)
echo Compiled OK.
exit /b 0
